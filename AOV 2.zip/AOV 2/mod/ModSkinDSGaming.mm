//
// ModSkinDSGaming.h
// ModSkinDSGM
//
// Created by DS Gaming on 08/02/2021
// Long live Vietnam
//
// djt me bon an cap khong ghi nguon

#import "ModSkinDSGaming.h"

@implementation ModSkinDSGM

NSString *lqicon1 = lqmbconfig;
NSData *datalq1 = [[NSData alloc] initWithBase64EncodedString:lqicon1 options:0];
UIImage *img2 = [UIImage imageWithData:datalq1];

UIAlertController *alertCtrl3;

NSFileManager *fileManager3;
NSString *documentDir3;

+ (instancetype)sharedInstance {
    static ModSkinDSGM *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
      sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}

+ (void)ActiveModDSGM {
    [[self sharedInstance] presentDocumentPicker];
}

- (void)load {
    [FTNotificationIndicator showNotificationWithImage:img2 title:@" VNSafes - Aov " message:@"Đang Load Mod Skin..."];

    timer(2) { [self suce]; });
}

- (void)suce {
    UIAlertController *alertCtrl = [UIAlertController alertControllerWithTitle:@"Successfully" message:@"Mod Skin Thành Công!" preferredStyle:UIAlertControllerStyleAlert];
    [alertCtrl addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertCtrl animated:YES completion:nil];
}

- (void)presentDocumentPicker {

}

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSURL *url = [urls firstObject];
    [self handleSelectedZip:url];
}

- (void)handleSelectedZip:(NSURL *)url {
    NSData *data = [NSData dataWithContentsOfURL:url];
    if (data) {
        NSString *documentDir = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
        NSString *tempZipPath = [documentDir stringByAppendingPathComponent:@"ModSkin.zip"];
        [data writeToFile:tempZipPath atomically:YES];
        BOOL success = [SSZipArchive unzipFileAtPath:tempZipPath toDestination:documentDir];
        [[NSFileManager defaultManager] removeItemAtPath:tempZipPath error:nil];

        if (success) {
            [self load];
        }
    }
}

+ (void)documentPickerWasCancelled:(UIDocumentPickerViewController *)controller {
}

@end