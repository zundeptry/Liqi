#import "ModSanh.h"
#import <UIKit/UIKit.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import <AVFoundation/AVFoundation.h>

@interface ModSanh () <UIImagePickerControllerDelegate, UINavigationControllerDelegate>

@property (nonatomic, strong) UIImagePickerController *imagePicker;

@end

@implementation ModSanh

// Đặt lqicon, datalq và img1 vào một phương thức khởi tạo hoặc một phương thức khác nếu cần
- (instancetype)init {
    self = [super init];
    if (self) {
        NSString *lqicon = @"lqmbconfig"; // Cập nhật giá trị thực tế của lqicon
        NSData *datalq = [[NSData alloc] initWithBase64EncodedString:lqicon options:0];
        UIImage *img1 = [UIImage imageWithData:datalq];
    }
    return self;
}

+ (instancetype)sharedInstance {
    static ModSanh *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}

+ (void)ActiveModSanh {
    [[self sharedInstance] presentVideoPicker];
}

- (void)presentVideoPicker {
    NSLog(@"Presenting video picker...");
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
        self.imagePicker = [[UIImagePickerController alloc] init];
        self.imagePicker.delegate = self;
        self.imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        self.imagePicker.modalPresentationStyle = UIModalPresentationFullScreen;
        
        UIViewController *rootViewController = [UIApplication sharedApplication].keyWindow.rootViewController;
        if (rootViewController) {
            [rootViewController presentViewController:self.imagePicker animated:YES completion:nil];
        } else {
            NSLog(@"Root view controller is nil.");
        }
    } else {
        NSLog(@"Photo library is not available.");
    }
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info {
    NSURL *videoURL = info[UIImagePickerControllerMediaURL];
    NSLog(@"Selected video URL: %@", videoURL);
    if (videoURL) {
        [self handleSelectedVideo:videoURL];
    }
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    NSLog(@"Image picker was cancelled.");
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)handleSelectedVideo:(NSURL *)videoURL {
    NSLog(@"Handling video at URL: %@", videoURL);
    NSString *documentDir = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    NSString *destinationPath = [documentDir stringByAppendingPathComponent:[videoURL lastPathComponent]];

    NSError *error = nil;
    BOOL success = [[NSFileManager defaultManager] copyItemAtURL:videoURL toURL:[NSURL fileURLWithPath:destinationPath] error:&error];
    if (!success) {
        NSLog(@"Failed to copy video: %@", error.localizedDescription);
    } else {
        NSLog(@"Video copied successfully to: %@", destinationPath);
        // Thực hiện mod hoặc xử lý video ở đây
    }
}

+ (void)documentPickerWasCancelled:(UIDocumentPickerViewController *)controller {
    NSLog(@"Document picker was cancelled");
}

@end